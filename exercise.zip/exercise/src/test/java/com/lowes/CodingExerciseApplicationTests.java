package com.lowes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
