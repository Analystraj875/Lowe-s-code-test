package com.lowes.model.mapper;

import com.lowes.model.Category;
import com.lowes.model.Result;
import com.lowes.model.dto.CategoryDto;
import com.lowes.model.dto.QuizDto;
import com.lowes.model.dto.ResultDto;
import reactor.core.publisher.Mono;

import java.util.List;

public class QuizMapper {
    public static Mono<CategoryDto> map(Category category) {
        List<Result> result = category.getResults();
        CategoryDto categoryDto = CategoryDto.builder().category(result.get(0).getCategory()).build();
        result.stream().map(QuizMapper::convertResult).forEach(categoryDto::addResults);
        return Mono.just(categoryDto);
    }

    public static QuizDto getQuiz(List<CategoryDto> categoryDtos) {
        return QuizDto.builder().quiz(categoryDtos).build();
    }


    private static ResultDto convertResult(Result result) {
        ResultDto resultDto = ResultDto.builder()
                .difficulty(result.getDifficulty())
                .question(result.getQuestion())
                .type(result.getType())
                .all_answers(result.getIncorrect_answers())
                .correct_answer(result.getCorrect_answer())
                .build();
        resultDto.addToAllAnswers(result.getCorrect_answer());
        return resultDto;
    }


}
