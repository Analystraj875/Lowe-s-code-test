package com.lowes.model.dto;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ResultDto {
    private String type;
    private String difficulty;
    private String question;
    @Builder.Default
    private List<String> all_answers=new ArrayList<>();
    private String correct_answer;

    public void addToAllAnswers(String correct_answer) {
        all_answers.add(correct_answer);
    }
}
