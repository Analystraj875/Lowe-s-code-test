package com.lowes.model.dto;

import lombok.*;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class CategoryDto {
    private String category;
    @Builder.Default
    private List<ResultDto> results= new ArrayList<>();

    public void addResults(ResultDto result) {
        this.results.add(result);
    }
}
