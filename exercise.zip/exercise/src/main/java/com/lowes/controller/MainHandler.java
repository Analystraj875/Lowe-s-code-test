package com.lowes.controller;

import com.lowes.model.dto.CategoryDto;
import com.lowes.model.dto.QuizDto;
import com.lowes.model.mapper.QuizMapper;
import com.lowes.service.DownStreamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class MainHandler {
    @Autowired
    DownStreamService downStreamService;

    public Mono<ServerResponse> handleRequest(ServerRequest serverRequest) {
        Flux<CategoryDto> flux = Flux.concat(downStreamService.getQuiz("12"), downStreamService.getQuiz("11"))
                .flatMap(QuizMapper::map);
        Mono<QuizDto> category = flux.collectList().map(QuizMapper::getQuiz);
        return ServerResponse.ok()
                .body(category
                        , QuizDto.class);

    }


}
