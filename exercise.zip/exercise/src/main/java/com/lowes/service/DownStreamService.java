package com.lowes.service;

import com.lowes.model.Category;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Service
public class DownStreamService {
    @Autowired
    WebClient webClient;
    public Flux<Category> getQuiz(String category) {
        return webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api.php")
                        .queryParam("category", category)
                        .queryParam("amount", "5")
                        .build())
                .accept(MediaType.APPLICATION_JSON)
                .exchangeToFlux(clientResponse -> clientResponse.bodyToFlux(Category.class));
    }
}
